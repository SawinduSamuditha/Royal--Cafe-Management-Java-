package AdminPage;

import AdminPage.DataBaseInputPanel.DatabaseInput;
import AdminPage.ItemPanel.ItemPanelDetails;

import ItemPage.ControlbtnPanel;
import ItemPage.ItemPanel.ItemDetails;
import ItemPage.Search.SearchPanel;

import ItemPage.emptyPanel;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainScreen3 extends JFrame {

    private JPanel SearchBar;
    private JPanel Controlbtn;

    private JPanel dataPanel;
    private JPanel itemTital;

    private JPanel EmptyPanel;

    private JPanel ItemDetails;
    private  JPanel UpdateANDDelete;
    private JButton addBtn,deleteBtn,updateBtn,clearBtn;

    private JButton Delete;
    public MainScreen3() throws HeadlessException {
        this("Admin Application");
    }

    public MainScreen3(String title) throws HeadlessException{
        super(title);
        SearchBar = new SearchPanel();
        Controlbtn = new ControlbtnPanel();
        dataPanel = new DatabaseInput();
        itemTital = new ItemDetails();
        ItemDetails = new ItemPanelDetails();
        EmptyPanel = new emptyPanel();


        addBtn = new JButton("Add");
        deleteBtn = new JButton("Delete");
        updateBtn = new JButton("Update");
        clearBtn = new JButton("Clear");



        setBackground(new Color(155,176,193));
        InitializeUI();

    }

    public void InitializeUI(){
        //getContentPane().setBackground(new Color(234, 223, 180));
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        JPanel Search = new JPanel();
        Search.setLayout(new BorderLayout());
        Search.add(SearchBar,BorderLayout.NORTH);
        Search.add(dataPanel,BorderLayout.CENTER);
        //Search.add(btn,BorderLayout.SOUTH);



        JPanel Control = new JPanel();
        Control.setLayout(new BorderLayout());
        //Control.add(Controlbtn,BorderLayout.NORTH);
        Control.add(ItemDetails,BorderLayout.CENTER);
        Control.add(itemTital,BorderLayout.NORTH);
        Control.add(EmptyPanel,BorderLayout.SOUTH);


        JPanel ControlBar = new JPanel();
        ControlBar.setLayout(new BorderLayout());
        ControlBar.add(Controlbtn,BorderLayout.EAST);

        JPanel btnPanel = new JPanel();
        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(clearBtn);



        container.add(ControlBar,BorderLayout.NORTH);
        container.add(Control,BorderLayout.CENTER);
        container.add(Search,BorderLayout.WEST);
        container.add(btnPanel,BorderLayout.SOUTH);



        //Handling add event using anonymous class
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField nameTextField = new JTextField();
                JTextField phoneNumberTextField =new JTextField();
                //Created a component array
                //inside this array it have 4 components (two text fields and two labels)
                Component[] components = dataPanel.getComponents();
                for(Component cmp : components)
                {
                    if(cmp instanceof JTextField && cmp.getName().equals("nameFieldName"))
                    {
                        nameTextField = (JTextField) cmp;
                    }
                    else if(cmp instanceof JTextField && cmp.getName().equals("phoneNumberFieldName"))
                    {
                        phoneNumberTextField = (JTextField) cmp;
                    }
                }
                if(nameTextField.getText().isEmpty() || phoneNumberTextField.getText().isEmpty())
                {
                    JOptionPane.showMessageDialog(btnPanel,"Both fields must be filled");
                }
                else {
                    System.out.println(nameTextField.getText());
                    System.out.println(phoneNumberTextField.getText());

                    }

                }


    });



       /* JPanel btn = new JPanel();
        btn.setLayout(new BorderLayout());
        btn.add(Insert,BorderLayout.WEST);
        btn.add(Delete,BorderLayout.EAST);*/

        /*JPanel BtnPanel = new JPanel();
        BtnPanel.setLayout(new BorderLayout());
        BtnPanel.add(Insert,BorderLayout.WEST);
        BtnPanel.add(UpdateANDDelete,BorderLayout.CENTER);
        //btnPanel.add(Delete,BorderLayout.EAST);*/


        //btnPanel.setBackground(new Color(234, 223, 180));
        //add(btnPanel,BorderLayout.CENTER);



        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new MainScreen3();
    }
}
