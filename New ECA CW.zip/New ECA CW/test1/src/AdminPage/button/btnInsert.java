/*package AdminPage.button;

import AdminPage.DataBaseInputPanel.DatabaseInput;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnInsert extends JButton {
    public btnInsert() {
        super("Insert");
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                // Create JTextFields outside the loop
                JTextField IDField = new JTextField();
                JTextField NameField = new JTextField();
                JTextField PriceField = new JTextField();
                JTextField quantityField = new JTextField();

                DatabaseInput databaseInput = new DatabaseInput();
                //MainScreen3 mainScreen3 = new MainScreen3();
                JPanel btnPanel = new JPanel();
                Component[] components = databaseInput.getComponents();

                for (Component cmp : components) {
                    if (cmp instanceof JTextField && cmp.getName().equals("IDFieldName")) {
                        IDField = (JTextField) cmp;
                    } else if (cmp instanceof JTextField && cmp.getName().equals("NameFieldName")) {
                        NameField = (JTextField) cmp;
                    } else if (cmp instanceof JTextField && cmp.getName().equals("PriceFieldName")) {
                        PriceField = (JTextField) cmp;
                    } else if (cmp instanceof JTextField && cmp.getName().equals("quantityFieldName")) {
                        quantityField = (JTextField) cmp;
                    }
                }

                if (IDField.getText().isEmpty() || NameField.getText().isEmpty() || PriceField.getText().isEmpty() || quantityField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(btnPanel, "Both fields must be filled");
                } else {
                    System.out.println(IDField.getText());
                    System.out.println(NameField.getText());
                    System.out.println(PriceField.getText());
                    System.out.println(quantityField.getText());
                }
            }
        });
    }
}


}*//*
package AdminPage.button;

import AdminPage.DataBaseInputPanel.DatabaseInput;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class btnInsert extends JButton {
    public btnInsert() {
        super("Insert");
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // Create JTextFields outside the loop
                JTextField IDField = new JTextField();
                JTextField NameField = new JTextField();
                JTextField PriceField = new JTextField();
                JTextField quantityField = new JTextField();

                DatabaseInput databaseInput = new DatabaseInput();
                JPanel btnPanel = new JPanel();
                Component[] components = databaseInput.getComponents();

                for (Component cmp : components) {
                    if (cmp instanceof JTextField && cmp.getName().equals("IDFieldName")) {
                        IDField = (JTextField) cmp;
                    } else if (cmp instanceof JTextField && cmp.getName().equals("NameFieldName")) {
                        NameField = (JTextField) cmp;
                    } else if (cmp instanceof JTextField && cmp.getName().equals("PriceFieldName")) {
                        PriceField = (JTextField) cmp;
                    } else if (cmp instanceof JTextField && cmp.getName().equals("quantityFieldName")) {
                        quantityField = (JTextField) cmp;
                    }
                }

                if (IDField.getText().isEmpty() || NameField.getText().isEmpty() || PriceField.getText().isEmpty() || quantityField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(btnPanel, "All fields must be filled");
                } else {
                    // Insert data into the database
                    if (insertData(IDField.getText(), NameField.getText(), PriceField.getText(), quantityField.getText())) {
                        System.out.println("Data inserted successfully");
                    } else {
                        JOptionPane.showMessageDialog(btnPanel, "Error inserting data into the database", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
    }*/
/*
    private boolean insertData(String id, String name, String price, String quantity) {
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/royal_cafe";
        String username = "root";
        String password = "admin123";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            try (Connection connection = DriverManager.getConnection(url, username, password)) {

                // Define the SQL query for insertion
                String sql = "INSERT INTO items (Item_ID, Item_Name, Price, Quantity) VALUES (?, ?, ?, ?)";

                // Create a PreparedStatement with the query
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

                    // Set the values for the parameters
                    preparedStatement.setString(1, id);
                    preparedStatement.setString(2, name);
                    preparedStatement.setString(3, price);
                    preparedStatement.setString(4, quantity);

                    // Execute the insertion query
                    preparedStatement.executeUpdate();
                }
            }

            return true; // Indicates successful insertion
        } catch (Exception ex) {
            ex.printStackTrace();
            return false; // Indicates an error during insertion
        }
    }
}*/
package AdminPage.button;

import AdminPage.DataBaseInputPanel.DatabaseInput;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnInsert extends JButton {
    public btnInsert() {
        super("Insert");
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                DatabaseInput databaseInput = new DatabaseInput();
                Component[] components = databaseInput.getComponents();

                String idText = "";
                String nameText = "";
                String priceText = "";
                String quantityText = "";

                for (Component cmp : components) {
                    if (cmp instanceof JTextField) {
                        JTextField textField = (JTextField) cmp;

                        if ("IDFieldName".equals(textField.getName())) {
                            idText = textField.getText();
                        } else if ("NameFieldName".equals(textField.getName())) {
                            nameText = textField.getText();
                        } else if ("PriceFieldName".equals(textField.getName())) {
                            priceText = textField.getText();
                        } else if ("quantityFieldName".equals(textField.getName())) {
                            quantityText = textField.getText();
                        }
                    }
                }

                if (idText.isEmpty() || nameText.isEmpty() || priceText.isEmpty() || quantityText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields must be filled");
                } else {
                    System.out.println(idText);
                    System.out.println(nameText);
                    System.out.println(priceText);
                    System.out.println(quantityText);
                }
            }
        });
    }
}


