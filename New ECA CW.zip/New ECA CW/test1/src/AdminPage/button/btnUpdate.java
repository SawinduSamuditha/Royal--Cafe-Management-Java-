package AdminPage.button;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnUpdate extends JPanel {

    private JButton update;
    private JButton delete;
    public btnUpdate() {
        //this.title = new JLabel();
        setLayout(new BorderLayout());
        initializeTitleBarUI();
    }


    public void initializeTitleBarUI() {
       /* JPanel coloredPanel = new JPanel();
        title.setText("Royal Cafe");
        coloredPanel.setBackground(new Color(97,163,186));
        coloredPanel.add(title);*/

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        update = new JButton("Update");

        //delete = new JButton("Delete");

        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });



    }
}
