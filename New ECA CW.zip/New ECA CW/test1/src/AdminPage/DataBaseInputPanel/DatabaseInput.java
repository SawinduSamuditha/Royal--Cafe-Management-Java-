package AdminPage.DataBaseInputPanel;

import javax.swing.*;
import java.awt.*;

public class DatabaseInput extends JPanel {

    private JLabel itemID,itemName,price,quantity;

    private JTextField IDField,NameField,PriceField,quantityField;

    private JButton insert;
    private JPanel update;
    private JButton clear;
    private JButton delete;

    public DatabaseInput(){

        setLayout(new GridLayout(7,3));
        //update = new btnUpdate();

        initializeUI();

        //initializebtnUI();

    }

    public void initializeUI() {
        //setBackground(new Color(234, 223, 180));

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(), 15));

        itemID = new JLabel("Item ID");
        itemName = new JLabel("Item Name");
        price = new JLabel("Price");
        quantity = new JLabel("Quantity");
        //avilableQ = new JLabel("Available Quantity");
        //nextItems = new JButton("Next Item");

        IDField = new JTextField(12);
        IDField.setName("IDFieldName");

        NameField = new JTextField(12);
        NameField.setName("NameFieldName");

        PriceField = new JTextField(12);
        PriceField.setName("PriceFieldName");

        quantityField = new JTextField(12);
        quantityField.setName("quantityFieldName");



        //AvilableField = new JTextField(12);


        add(itemID);
        add(IDField);

        add(itemName);
        add(NameField);

        add(price);
        add(PriceField);

        add(quantity);
        add(quantityField);

       /* add(insert);
        add(update);
        add(delete);
        add(clear);*/

    }

}
