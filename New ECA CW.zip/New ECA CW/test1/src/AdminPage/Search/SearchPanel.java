package AdminPage.Search;

import javax.swing.*;
import java.awt.*;

public class SearchPanel extends JPanel {
    private JLabel search;

    private JTextField searchField;

    public SearchPanel(){
        setLayout(new GridLayout(1,1));
        initializeSearchUI();
    }

    public void initializeSearchUI(){
        setBackground(new Color(234, 223, 180));

        search = new JLabel("Search");
        //btnnewBil = new JButton("New Bill");
        searchField = new JTextField(2);
        search.setBackground(new Color(234, 223, 180));

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        JPanel SearchANDbtnPanel = new JPanel();
        SearchANDbtnPanel.setLayout(new BorderLayout());
        SearchANDbtnPanel.add(search,BorderLayout.NORTH);
        SearchANDbtnPanel.add(searchField,BorderLayout.CENTER);
        //SearchANDbtnPanel.add(btnnewBil,BorderLayout.EAST);
        SearchANDbtnPanel.add(emptyPanel,BorderLayout.SOUTH);

        SearchANDbtnPanel.setBackground(new Color(234, 223, 180));
        add(SearchANDbtnPanel,BorderLayout.CENTER);

    }
}
