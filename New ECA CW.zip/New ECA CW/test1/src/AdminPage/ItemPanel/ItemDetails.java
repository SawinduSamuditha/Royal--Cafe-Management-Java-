package AdminPage.ItemPanel;

import javax.swing.*;
import java.awt.*;

public class ItemDetails extends JPanel {

    private  JLabel title;
    public ItemDetails(){
        this.title = new JLabel();
        setLayout(new BorderLayout());
        initializeTitleBarUI();
    }


    public void initializeTitleBarUI() {
        JPanel coloredPanel = new JPanel();
        title.setText("Item Details");
        coloredPanel.setBackground(new Color(234, 223, 180));
        coloredPanel.add(title);

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        JPanel emptyPanel1 = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        add(emptyPanel1,BorderLayout.WEST);
        add(coloredPanel,BorderLayout.CENTER);
        add(emptyPanel,BorderLayout.SOUTH);
    }
}

