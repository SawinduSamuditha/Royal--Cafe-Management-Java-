package ItemPage.UpdatelPanel;

import ItemPage.button.btnClear;
import ItemPage.button.btnUpdate;

import javax.swing.*;
import java.awt.*;

public class UpdateItemPanel extends JPanel {

    private JLabel itemID,itemName,price,quantity;

    private JTextField IDField,NameField,PriceField,quantityField;


    public UpdateItemPanel(){

        setLayout(new GridLayout(6,3));

        initializeUI();

        //initializebtnUI();

    }

    public void initializeUI() {
        //setBackground(new Color(234, 223, 180));

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        itemID = new JLabel("Item ID");
        itemName = new JLabel("Item Name");
        price = new JLabel("Price");
        quantity = new JLabel("Quantity");
        //avilableQ = new JLabel("Available Quantity");
        //nextItems = new JButton("Next Item");

        IDField = new JTextField(12);
        NameField = new JTextField(12);
        PriceField = new JTextField(12);
        quantityField =new JTextField(12);
        //AvilableField = new JTextField(12);


        add(itemID);
        add(IDField);

        add(itemName);
        add(NameField);

        add(price);
        add(PriceField);

        add(quantity);
        add(quantityField);









    }
    /*public void initializebtnUI(){
        JPanel HomePage.BillPrint.emptyPanel = new JPanel();
        HomePage.BillPrint.emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        JPanel NewbtnPanel = new JPanel();
        NewbtnPanel.setLayout(new BorderLayout());
        NewbtnPanel.add(HomePage.BillPrint.emptyPanel,BorderLayout.SOUTH);
        NewbtnPanel.add(nextItems,BorderLayout.EAST);

        add(NewbtnPanel);

    }
    JPanel billANDbtn = new JPanel();*/

}
