package ItemPage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlbtnPanel extends JPanel {

    //private  JLabel title;

    private JButton itemSell;
    private JButton signOut;
    public ControlbtnPanel(){
        //this.title = new JLabel();
        setLayout(new BorderLayout());
        initializeTitleBarUI();
    }


    public void initializeTitleBarUI() {
       /* JPanel coloredPanel = new JPanel();
        title.setText("Royal Cafe");
        coloredPanel.setBackground(new Color(97,163,186));
        coloredPanel.add(title);*/

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        itemSell = new JButton("Item Sell");

        signOut = new JButton("Sign Out");

        itemSell.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        signOut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        JPanel controlbtn = new JPanel();
        controlbtn.setLayout(new BorderLayout());
        controlbtn.add(itemSell,BorderLayout.CENTER);
        controlbtn.add(signOut,BorderLayout.EAST);


        //add(coloredPanel,BorderLayout.CENTER);
        //add(HomePage.BillPrint.emptyPanel,BorderLayout.SOUTH);
        add(controlbtn,BorderLayout.EAST);
        //add(emptyPanel,BorderLayout.SOUTH);
    }
}



