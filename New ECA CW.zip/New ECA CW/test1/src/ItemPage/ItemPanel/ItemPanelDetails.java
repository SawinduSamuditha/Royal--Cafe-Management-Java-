/*package AdminPage.ItemPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ItemPanelDetails {


    public class ItemPanelDetails() extends JPanel {

        private JTable table;
        private JButton btnDelete;

        public ItemsDetailsPanel() {
            setLayout(new BorderLayout());

            // Create a DefaultTableModel
            DefaultTableModel model = new DefaultTableModel();

            // Set column names
            model.setColumnIdentifiers(new Object[]{"ID", "Name", "Price", "Quantity"});

            // Retrieve data from the database
            fetchDataFromDatabase(model);

            // Create the JTable with the DefaultTableModel
            table = new JTable(model);

            // Add the table to a JScrollPane
            JScrollPane scrollPane = new JScrollPane(table);

            // Add the JScrollPane to the panel (set to the center)
            add(scrollPane, BorderLayout.CENTER);

            // Display the panel
            setVisible(true);

            // Set the table selection mode
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            // initializeUI();


        }

        private void fetchDataFromDatabase(DefaultTableModel model) {
            // JDBC connection parameters
            String url = "jdbc:mysql://localhost:3306/royal_cafe";
            String username = "root";
            String password = "admin123";

            try {
                // Load the JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the connection
                Connection connection = DriverManager.getConnection(url, username, password);

                // Create a statement
                Statement statement = connection.createStatement();

                // Execute a query to retrieve data
                ResultSet rs = statement.executeQuery("SELECT * FROM items;");

                // Iterate through the result set and add data to the model
                while (rs.next()) {
                    int Item_ID = rs.getInt("ID");
                    String Item_Name = rs.getString("Name");
                    int Price = rs.getInt("Price");
                    int Quantity = rs.getInt("Quantity");
                    model.addRow(new Object[]{Item_ID, Item_Name, Price, Quantity});
                }

                // Close the resources
                rs.close();
                statement.close();
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void initializeUI() {
            JPanel emptyPanel = new JPanel();
            emptyPanel.setPreferredSize(new Dimension(getWidth(), 15));

            add(emptyPanel, BorderLayout.WEST);
        }
    }

}*/

package ItemPage.ItemPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ItemPanelDetails extends JPanel {

    private JTable table;

    public ItemPanelDetails() {
        setLayout(new BorderLayout());

        // Create a DefaultTableModel
        DefaultTableModel model = new DefaultTableModel();

        // Set column names
        model.setColumnIdentifiers(new Object[]{"Item_ID", "Item_Name", "Price", "Quantity"});

        // Retrieve data from the database
        fetchDataFromDatabase(model);

        // Create the JTable with the DefaultTableModel
        table = new JTable(model);

        // Add the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the JScrollPane to the panel (set to the center)
        add(scrollPane, BorderLayout.CENTER);

        // Display the panel
        setVisible(true);

        // Set the table selection mode
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // initializeUI();
    }

    private void fetchDataFromDatabase(DefaultTableModel model) {
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/royal_cafe";
        String username = "root";
        String password = "admin123";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a query to retrieve data
            ResultSet rs = statement.executeQuery("SELECT * FROM items");

            // Iterate through the result set and add data to the model
            while (rs.next()) {
                int ItemID = rs.getInt("Item_ID");
                String ItemName = rs.getString("Item_Name");
                int Price = rs.getInt("Price");
                int Quantity = rs.getInt("Quantity");
                model.addRow(new Object[]{ItemID, ItemName, Price, Quantity});
            }

            // Close the resources
            rs.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initializeUI() {
        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(), 15));

        add(emptyPanel, BorderLayout.WEST);
    }


}
