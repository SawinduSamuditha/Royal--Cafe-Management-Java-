package ItemPage.ItemPanel;/*import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;

public class Select.SelectDetailsPanel extends JPanel {


    private JTable table;

    private JButton btnDelete;
    public Select.SelectDetailsPanel() {

        setLayout(new BorderLayout());
        // Create a DefaultTableModel
        DefaultTableModel model = new DefaultTableModel();

        // Set column names
        model.setColumnIdentifiers(new Object[]{"ID","Name", "PhoneNumber"});

        // Retrieve data from the database
        fetchDataFromDatabase(model);

        // Create the JTable with the DefaultTableModel
        table = new JTable(model);
        // Add the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the JScrollPane to the frame
        add(scrollPane,BorderLayout.CENTER);
        // Display the frame
        setVisible(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        setLayout(new GridLayout(2,1));


        initializeDeleteUI();

    }

    private void fetchDataFromDatabase(DefaultTableModel model) {
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/contactlist";
        String username = "root";
        String password = "admin123";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a query to retrieve data
            ResultSet rs = statement.executeQuery("SELECT * FROM contacts");

            // Iterate through the result set and add data to the model
            while (rs.next()) {
                int ID;
                String name;
                String number;
                model.addRow(new Object[]{
                        ID = rs.getInt("ID"),
                        name = rs.getString("Name"),
                        number = rs.getString("PhoneNumber"),
                });
            }

            // Close the resources
            rs.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initializeDeleteUI(){
       // setBackground(new Color(234, 223, 180));


        btnDelete = new JButton("Delete");
        btnDelete.setBackground(new Color(234, 223, 180));

        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        JPanel DeletebtnPanel = new JPanel();
        DeletebtnPanel.setLayout(new BorderLayout());
        DeletebtnPanel.add(btnDelete,BorderLayout.SOUTH);

        DeletebtnPanel.setBackground(new Color(234, 223, 180));
        add(DeletebtnPanel);
    }
}*/

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ItemsDetailsPanel extends JPanel {

    private JTable table;
    private JButton btnDelete;

    public ItemsDetailsPanel() {
        setLayout(new BorderLayout());

        // Create a DefaultTableModel
        DefaultTableModel model = new DefaultTableModel();

        // Set column names
        model.setColumnIdentifiers(new Object[]{"ID", "Name", "PhoneNumber"});

        // Retrieve data from the database
        fetchDataFromDatabase(model);

        // Create the JTable with the DefaultTableModel
        table = new JTable(model);

        // Add the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the JScrollPane to the panel (set to the center)
        add(scrollPane, BorderLayout.CENTER);

        // Display the panel
        setVisible(true);

        // Set the table selection mode
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        initializeUI();





    }

    private void fetchDataFromDatabase(DefaultTableModel model) {
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/contactlist";
        String username = "root";
        String password = "admin123";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a query to retrieve data
            ResultSet rs = statement.executeQuery("SELECT * FROM contacts");

            // Iterate through the result set and add data to the model
            while (rs.next()) {
                int ID = rs.getInt("ID");
                String name = rs.getString("Name");
                String number = rs.getString("PhoneNumber");
                model.addRow(new Object[]{ID, name, number});
            }

            // Close the resources
            rs.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initializeUI() {
        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        add(emptyPanel,BorderLayout.WEST);
    }


}