package ItemPage;

import ItemPage.ItemPanel.ItemDetails;
import ItemPage.ItemPanel.ItemPanelDetails;
import ItemPage.ItemPanel.ItemsDetailsPanel;
import ItemPage.Search.SearchPanel;
import ItemPage.UpdatelPanel.UpdateItemPanel;
import ItemPage.button.btnClear;
import ItemPage.button.btnUpdate;

import javax.swing.*;
import java.awt.*;

public class MainScreen2 extends JFrame {

    private JPanel SearchBar;
    private JPanel Controlbtn;

    private JPanel UpdatePanel;
    private JPanel itemTital;

    private JPanel EmptyPanel;

    private JPanel ItemDetails;
    private  JButton Update;

    private JPanel btn;

    private JButton Clear;
    public MainScreen2() throws HeadlessException {
        this("Item Add Application");
    }

    public MainScreen2(String title) throws HeadlessException{
        super(title);
        SearchBar = new SearchPanel();
        Controlbtn = new ControlbtnPanel();
        UpdatePanel = new UpdateItemPanel();
        itemTital = new ItemDetails();
        ItemDetails = new ItemPanelDetails();
        EmptyPanel = new emptyPanel();

        Update = new btnUpdate();
        Clear = new btnClear();

        setBackground(new Color(155,176,193));
        InitializeUI();
    }

    public void InitializeUI(){
        //getContentPane().setBackground(new Color(234, 223, 180));
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        JPanel Search = new JPanel();
        Search.setLayout(new BorderLayout());
        Search.add(SearchBar,BorderLayout.NORTH);
        Search.add(UpdatePanel,BorderLayout.CENTER);
        //Search.add(btn,BorderLayout.SOUTH);



        JPanel Control = new JPanel();
        Control.setLayout(new BorderLayout());
        //Control.add(Controlbtn,BorderLayout.NORTH);
        Control.add(ItemDetails,BorderLayout.CENTER);
        Control.add(itemTital,BorderLayout.NORTH);
        Control.add(EmptyPanel,BorderLayout.SOUTH);


        JPanel ControlBar = new JPanel();
        ControlBar.setLayout(new BorderLayout());
        ControlBar.add(Controlbtn,BorderLayout.EAST);

        JPanel btn = new JPanel();
        btn.add(Update);
        btn.add(Clear);

        container.add(ControlBar,BorderLayout.NORTH);
        container.add(Control,BorderLayout.CENTER);
        container.add(Search,BorderLayout.WEST);
        container.add(btn,BorderLayout.SOUTH);

        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new MainScreen2();
    }
}
