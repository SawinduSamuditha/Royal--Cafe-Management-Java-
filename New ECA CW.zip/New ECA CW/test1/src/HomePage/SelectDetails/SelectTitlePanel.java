package HomePage.SelectDetails;

import javax.swing.*;
import java.awt.*;

public class SelectTitlePanel extends JPanel {

    private  JLabel title;
    public SelectTitlePanel(){
        this.title = new JLabel();
        setLayout(new BorderLayout());
        initializeTitleBarUI();
    }


    public void initializeTitleBarUI() {
        JPanel coloredPanel = new JPanel();
        title.setText("Select Item Details");
        coloredPanel.setBackground(new Color(234, 223, 180));
        coloredPanel.add(title);

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        JPanel emptyPanel1 = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        add(emptyPanel1,BorderLayout.WEST);
        add(coloredPanel,BorderLayout.CENTER);
        add(emptyPanel,BorderLayout.SOUTH);
    }
}

