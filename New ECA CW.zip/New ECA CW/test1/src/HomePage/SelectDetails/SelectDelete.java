package HomePage.SelectDetails;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SelectDelete extends JPanel {
    private JButton btnDelete;



    public SelectDelete(){
        initializeDeleteUI();
    }

    public void initializeDeleteUI(){
        btnDelete = new JButton("Delete");


        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        JPanel deleteBtnPanel = new JPanel();
        deleteBtnPanel.setLayout(new BorderLayout());
        deleteBtnPanel.add(btnDelete, BorderLayout.EAST);


        //JPanel emptyPanel1 = new JPanel();
       // HomePage.BillPrint.emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        // Add the delete button panel to the south
        add(deleteBtnPanel, BorderLayout.EAST);
        //add(emptyPanel1,BorderLayout.NORTH);
    }
}
