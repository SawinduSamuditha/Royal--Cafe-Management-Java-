package HomePage;

import javax.swing.*;
import java.awt.*;

public class emptyPanel extends JPanel {

    public emptyPanel(){
        initializeUI();
    }

    public void initializeUI(){
        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),20));

        add(emptyPanel,BorderLayout.CENTER);
    }
}
