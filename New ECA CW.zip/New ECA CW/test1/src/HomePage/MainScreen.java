package HomePage;

/*import javax.swing.*;
import java.awt.*;

import HomePage.BillPrint.BillText;
import HomePage.BillPrint.btnPrint;
import HomePage.Search.Search;
import HomePage.SelectDetails.SelectDelete;
import HomePage.SelectDetails.SelectDetailsPanel;
import HomePage.SelectDetails.SelectTitlePanel;
import HomePage.Total.TotalBillPanel;
import HomePage.selectItems.BilPanel;


public class HomePage.BillPrint.MainScreen extends JFrame {

    private JPanel titleBar;
    private JPanel SearchBar;

    private JPanel bilPanel;

    private JPanel totPanel;
    private JPanel selectDetails;
    private JPanel selectTitle;

    private JPanel btnDelete;



    public HomePage.BillPrint.MainScreen() throws HeadlessException{
        this("Home Application");
    }

    public HomePage.BillPrint.MainScreen(String title) throws HeadlessException{
        super(title);
        titleBar = new HomePage.BillPrint.TitlePanel();
        SearchBar = new HomePage.BillPrint.Search.HomePage.BillPrint.Search();
        bilPanel = new HomePage.BillPrint.selectItems.BilPanel();
        totPanel = new HomePage.BillPrint.Total.TotalBillPanel();
        selectDetails = new Select.SelectDetailsPanel();
        selectTitle = new Select.SelectTitlePanel();
        btnDelete = new Select.SelectDelete();



        InitializeUI();
    }

    public void InitializeUI(){

        getContentPane().setBackground(new Color(234, 223, 180));
        Container container = getContentPane();
        container.setLayout(new BorderLayout());


        container.add(titleBar,BorderLayout.NORTH);
        JPanel searchANDbilPanel = new JPanel();
        searchANDbilPanel.setLayout(new BorderLayout());

        searchANDbilPanel.add(SearchBar,BorderLayout.NORTH);
        searchANDbilPanel.add(bilPanel,BorderLayout.CENTER);
        searchANDbilPanel.add(totPanel,BorderLayout.SOUTH);

        container.add(searchANDbilPanel,BorderLayout.WEST);

        JPanel Selectitems = new JPanel();
        Selectitems.setLayout(new BorderLayout());

        Selectitems.add(selectTitle,BorderLayout.NORTH);
        Selectitems.add(selectDetails,BorderLayout.CENTER);
        Selectitems.add(btnDelete,BorderLayout.SOUTH);


        container.add(Selectitems,BorderLayout.CENTER);



        setSize(800, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new HomePage.BillPrint.MainScreen();
    }
}
*/


import HomePage.BillPrint.BillText;
import HomePage.BillPrint.btnPrint;
import HomePage.Search.Search;
import HomePage.SelectDetails.SelectDelete;
import HomePage.SelectDetails.SelectDetailsPanel;
import HomePage.SelectDetails.SelectTitlePanel;
import HomePage.Total.TotalBillPanel;
import HomePage.selectItems.BilPanel;

import javax.swing.*;
import java.awt.*;

public class MainScreen extends JFrame {

    private JPanel titleBar;
    private JPanel SearchBar;
    private JPanel bilPanel;
    private JPanel totPanel;
    private JPanel selectDetails;

    private JPanel SelectItemsDetails;
    private JPanel selectTitle;
    private JPanel btnDelete;
    private JPanel controlPanel;
    private  JPanel Emptybar;

    private JPanel emptyBar;

    private JPanel emptyLine;

    private JTextArea text;

    private JButton Print;



    public MainScreen() throws HeadlessException {
        this("Home Application");
        setBackground(new Color(155,176,193));
    }

    public MainScreen(String title) throws HeadlessException {
        super(title);
        titleBar = new TitlePanel();
        SearchBar = new Search();
        bilPanel = new BilPanel();
        totPanel = new TotalBillPanel();

        Emptybar = new emptyPanel();
        emptyBar = new emptyPanel();
        emptyLine = new emptyPanel();

        selectDetails = new SelectDetailsPanel();
        SelectItemsDetails = new SelectDetailsPanel();
        selectTitle = new SelectTitlePanel();
        btnDelete = new SelectDelete(); // Assuming Select.SelectDelete is a JPanel
        text = new BillText();
        Print = new btnPrint();

        //setBackground(new Color(155, 176, 193);
        setBackground(new Color(155,176,193));



        InitializeUI();


    }

    public void InitializeUI() {
        getContentPane().setBackground(new Color(234, 223, 180));
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

//-------------------------------------------------------------------
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BorderLayout());
        titlePanel.add(titleBar,BorderLayout.CENTER);
        titlePanel.add(Emptybar,BorderLayout.SOUTH);
//------------------------------------------------------------------
        JPanel SearchBill = new JPanel();
        SearchBill.setLayout(new BorderLayout());
        SearchBill.add(SelectItemsDetails,BorderLayout.CENTER);
        SearchBill.add(bilPanel,BorderLayout.SOUTH);
//------------------------------------------------------------------
        JPanel tot = new JPanel();
        tot.setLayout(new BorderLayout());
        tot.add(totPanel,BorderLayout.SOUTH);
        tot.add(emptyLine,BorderLayout.WEST);
//-------------------------------------------------------------------

        JPanel searchANDbilPanel = new JPanel();
        searchANDbilPanel.setLayout(new BorderLayout());
        searchANDbilPanel.add(SearchBar, BorderLayout.NORTH);
        searchANDbilPanel.add(SearchBill, BorderLayout.CENTER);
        searchANDbilPanel.add(tot,BorderLayout.SOUTH);
//-------------------------------------------------------------------

        JPanel selectItems = new JPanel(); // Fix the typo in the variable name
        selectItems.setLayout(new BorderLayout());
        selectItems.add(selectTitle, BorderLayout.NORTH);
        selectItems.add(selectDetails, BorderLayout.CENTER);
        selectItems.add(btnDelete, BorderLayout.SOUTH);
        selectItems.add(Emptybar,BorderLayout.WEST);
//--------------------------------------------------------------------
        JPanel textArea = new JPanel();
        textArea.setLayout(new BorderLayout());
        textArea.add(text,BorderLayout.CENTER);
        textArea.add(Print,BorderLayout.SOUTH);
        textArea.add(emptyBar,BorderLayout.WEST);

//-------------------------------------------------------------------



       //Container
        container.add(titlePanel,BorderLayout.NORTH);
        container.add(searchANDbilPanel, BorderLayout.WEST);
        container.add(selectItems, BorderLayout.CENTER);
        container.add(textArea,BorderLayout.EAST);


        setSize(1000, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }


    public static void main(String[] args) {
        new MainScreen();
    }
}

