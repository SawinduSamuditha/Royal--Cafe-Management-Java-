package HomePage.BillPrint;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnPrint extends JButton {
    private JButton print;

    public btnPrint(){
        initializebtnUI();
    }

    public void initializebtnUI(){
        print = new JButton("Print");
        print.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        add(print);

    }

}
