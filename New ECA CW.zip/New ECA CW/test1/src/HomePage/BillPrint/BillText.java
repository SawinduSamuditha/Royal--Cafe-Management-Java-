package HomePage.BillPrint;

import javax.swing.JTextArea;

public class BillText extends JTextArea {

    public BillText() {
        initializeUI();
    }

    private void initializeUI() {
        setColumns(20);
        setRows(5);
    }
}