package HomePage.Total;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnPay extends JButton {
    private JButton pay;

    public btnPay(){
        initializebtnUI();
    }

    public void initializebtnUI(){
        pay = new JButton("Pay");
        pay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        add(pay);

    }
}
