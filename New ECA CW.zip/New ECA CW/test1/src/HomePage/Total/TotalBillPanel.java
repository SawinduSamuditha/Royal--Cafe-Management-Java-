package HomePage.Total;

import javax.swing.*;
import java.awt.*;

public class TotalBillPanel extends JPanel {
    /*private JLabel total,cash,balance;

    private JTextField totField,cashField,balanceField;

    private JButton pay;

    public HomePage.BillPrint.Total.TotalBillPanel(){
        setLayout(new GridLayout());
        initializeUI();
    }

    public void initializeUI(){
        setBackground(new Color(234, 223, 180));
        total = new JLabel("HomePage.BillPrint.Total");
        cash = new JLabel("Cash");
        balance = new JLabel("Balance");

        totField = new JTextField(3);
        cashField = new JTextField(3);
        balanceField = new JTextField(3);

        pay = new JButton("Pay");
        pay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        //JPanel payPanel = new JPanel();
        add(total);
        add(totField);

        add(cash);
        add(cashField);

        add(balance);
        add(balanceField);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(234, 223, 180));
        btnPanel.add(pay);

        JPanel HomePage.BillPrint.emptyPanel = new JPanel();
        HomePage.BillPrint.emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        //add(payPanel,BorderLayout.WEST);
        //add(btnPanel,BorderLayout.SOUTH);
        JPanel bill = new JPanel();
        bill.setLayout(new BorderLayout());
        bill.add(btnPanel,BorderLayout.SOUTH);
        bill.setBackground(new Color(234, 223, 180));
        add(bill,BorderLayout.CENTER);
        add(HomePage.BillPrint.emptyPanel,BorderLayout.NORTH);
        //bill.add(HomePage.BillPrint.emptyPanel,BorderLayout.SOUTH);

        */

    private JLabel total,cash,balance;

    private JTextField totField,cashField,balanceField;

    private JPanel emptyPanel;



    private JButton pay;

    public TotalBillPanel(){
        setLayout(new GridLayout(4,3));
        pay = new btnPay();
        initializeUI();
    }
    public void initializeUI() {
        JPanel tot = new JPanel();
        tot.setBackground(new Color(234, 223, 180));
        total = new JLabel("Total");
        cash = new JLabel("Cash");
        balance = new JLabel("Balance");


        totField = new JTextField(12);
        cashField = new JTextField(12);
        balanceField = new JTextField(12);



        add(total); //row1,columns1
        add(totField); //row1,columns2

        add(cash); //row2,columns1
        add(cashField); //row2,colums2

        add(balance); //row2,columns1
        add(balanceField); //row2,colums2

       /* pay = new JButton("Pay");
        pay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });*/

        add(pay);

        //add(pay);

       // JPanel emptyPanel1 = new JPanel();
       // emptyPanel1.setPreferredSize(new Dimension(getWidth(),15));

    }
}
