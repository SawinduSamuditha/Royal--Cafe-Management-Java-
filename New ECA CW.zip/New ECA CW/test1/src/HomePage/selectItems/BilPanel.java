package HomePage.selectItems;

import javax.swing.*;
import java.awt.*;

public class BilPanel extends JPanel {

    private JLabel quantity,itemID,itemName,price,avilableQ;

    private JTextField quantityField,IDField,NameField,PriceField,AvilableField;

    private JButton newItem;
    public BilPanel(){

        setLayout(new GridLayout(6,3));
        newItem = new btnNewItems();
        initializeUI();

        //initializebtnUI();

    }

    public void initializeUI() {
        //setBackground(new Color(234, 223, 180));

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        quantity = new JLabel("Quantity");
        itemID = new JLabel("Item ID");
        itemName = new JLabel("Item Name");
        price = new JLabel("Price");
        avilableQ = new JLabel("Available Quantity");
        //nextItems = new JButton("Next Item");

        quantityField =new JTextField(12);
        IDField = new JTextField(12);
        NameField = new JTextField(12);
        PriceField = new JTextField(12);
        AvilableField = new JTextField(12);


        add(quantity);
        add(quantityField);

        add(itemID);
        add(IDField);

        add(itemName);
        add(NameField);

        add(price);
        add(PriceField);

        add(avilableQ);
        add(AvilableField);





        add(newItem);

    }
    /*public void initializebtnUI(){
        JPanel HomePage.BillPrint.emptyPanel = new JPanel();
        HomePage.BillPrint.emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        JPanel NewbtnPanel = new JPanel();
        NewbtnPanel.setLayout(new BorderLayout());
        NewbtnPanel.add(HomePage.BillPrint.emptyPanel,BorderLayout.SOUTH);
        NewbtnPanel.add(nextItems,BorderLayout.EAST);

        add(NewbtnPanel);

    }
    JPanel billANDbtn = new JPanel();*/

}
