package HomePage.Search;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnNew extends JButton {
    private JButton newBill;

    public btnNew(){
        initializebtnUI();
    }

    public void initializebtnUI(){
        newBill = new JButton("New Bill");
        newBill.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });

        add(newBill);

    }


}
