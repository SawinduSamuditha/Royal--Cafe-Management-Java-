package HomePage.Search;

import javax.swing.*;
import java.awt.*;

public class Search  extends JPanel {

    private JLabel search;

    private JTextField searchField;
    private JButton btnnewBil;

    public Search(){
        setLayout(new GridLayout(1,1));
        btnnewBil = new btnNew();
        initializeSearchUI();
    }

    public void initializeSearchUI(){
        setBackground(new Color(234, 223, 180));

        search = new JLabel("Search");
        //btnnewBil = new JButton("New Bill");
        searchField = new JTextField(2);
        search.setBackground(new Color(234, 223, 180));

        //JPanel searchPanel = new JPanel();
        //searchPanel.add(search);
        //searchPanel.add(searchField);

        //JPanel btnPanel = new JPanel();
        //btnPanel.add(btnnewBil);

        /*btnnewBil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Click");
            }
        });*/

        JPanel emptyPanel = new JPanel();
        emptyPanel.setPreferredSize(new Dimension(getWidth(),15));

        /*JPanel SPanel = new JPanel();
        SPanel.setLayout(new BorderLayout());
        SPanel.add(HomePage.BillPrint.emptyPanel,BorderLayout.NORTH);
        SPanel.add(search,BorderLayout.CENTER);
        add(SPanel);*/


        JPanel SearchANDbtnPanel = new JPanel();
        SearchANDbtnPanel.setLayout(new BorderLayout());
        SearchANDbtnPanel.add(search,BorderLayout.NORTH);
        SearchANDbtnPanel.add(searchField,BorderLayout.CENTER);
        //SearchANDbtnPanel.add(btnnewBil,BorderLayout.EAST);
        SearchANDbtnPanel.add(emptyPanel,BorderLayout.SOUTH);
        SearchANDbtnPanel.add(btnnewBil,BorderLayout.EAST);




        SearchANDbtnPanel.setBackground(new Color(234, 223, 180));
        add(SearchANDbtnPanel,BorderLayout.CENTER);


    }
}
